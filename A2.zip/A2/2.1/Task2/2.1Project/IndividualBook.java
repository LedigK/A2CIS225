public class IndividualBook {
    private Book book;
    
     public IndividualBook(String authorLastName, String authorFirstName, String isbnNumber, String bookTitle, String publicationDate, int numberOfPages) {
        this.book = new Book(authorLastName, authorFirstName, isbnNumber, bookTitle, publicationDate, numberOfPages);
    }
    
    public void printAuthor() {
        System.out.println("Author: " + book.getAuthorLastName() + ", " + book.getAuthorFirstName());
    }

    public void printISBN() {
        System.out.println("ISBN: " + book.getIsbnNumber());
    }

    public void printTitle() {
        System.out.println("Title: " + book.getBookTitle());
    }

    public void printPublicationDate() {
        System.out.println("Publication Date: " + book.getPublicationDate());
    }

    public void printNumberOfPages() {
        if (book.getNumberOfPages() < 10) {
            System.out.println("Error: Number of pages is below ten!");
        } else {
            System.out.println("Number of Pages: " + book.getNumberOfPages());
        }
    }
}


