public class Book {
    private String authorLastName;
    private String authorFirstName;
    private String isbnNumber;
    private String bookTitle;
    private String publicationDate;
    private int numberOfPages;

    public Book(String authorLastName, String authorFirstName, String isbnNumber, String bookTitle, String publicationDate, int numberOfPages) {
        this.authorLastName = authorLastName;
        this.authorFirstName = authorFirstName;
        this.isbnNumber = isbnNumber;
        this.bookTitle = bookTitle;
        this.publicationDate = publicationDate;
        this.numberOfPages = numberOfPages;
    }

    public String getAuthorLastName() {
        return authorLastName;
    }

    public String getAuthorFirstName() {
        return authorFirstName;
    }

    public String getIsbnNumber() {
        return isbnNumber;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public String getPublicationDate() {
        return publicationDate;
    }

    public int getNumberOfPages() {
        return numberOfPages;
    }
}

